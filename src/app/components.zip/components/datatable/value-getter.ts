
export interface ValueGetter {
  value(item: any): any;
}
