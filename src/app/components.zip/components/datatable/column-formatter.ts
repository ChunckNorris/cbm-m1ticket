
export interface ColumnFormatter {
  format(item: any): string;
}
