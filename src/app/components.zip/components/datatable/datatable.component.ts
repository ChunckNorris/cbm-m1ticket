
import * as _ from 'lodash';

import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DataTableColumn } from './datatable-column';

@Component({
  selector: 'datatable',
  templateUrl: './datatable.component.html'
})
export class DataTableComponent implements OnInit {

  loading: boolean = false;
  allSelected: boolean = false;

  @Input() allowClone: boolean = false;
  @Input() columns: DataTableColumn[] = [];
  @Input() dismissButton: boolean = false;
  @Input() filterable: boolean = false;
  @Input() page: number = 1;
  @Input() showActions: boolean = false;
  @Input() showDeleteOnly: boolean = false;
  @Input() showCheckboxes: boolean = false;
  @Input() showPagination: boolean = false;
  @Input() showInfo: boolean = false;
  @Input() showManage: boolean = false;
  @Input() sortable: boolean = false;
  @Input() sortColumn: number = 1;
  @Input() sortAscending: boolean = true;
  @Input() typeName: string;
  @Output() onCheck: EventEmitter<any> = new EventEmitter();
  @Output() onClone: EventEmitter<any> = new EventEmitter();
  @Output() onActivate: EventEmitter<any> = new EventEmitter();
  @Output() onDelete: EventEmitter<any> = new EventEmitter();
  @Output() onEdit: EventEmitter<any> = new EventEmitter();
  @Output() onNavigate: EventEmitter<any> = new EventEmitter();
  @Output() onInfo: EventEmitter<any> = new EventEmitter();
  @Output() onManage: EventEmitter<any> = new EventEmitter();
  @Output() onSelectAll: EventEmitter<any> = new EventEmitter();
  @Output() onDeselectAll: EventEmitter<any> = new EventEmitter();

  @Input()
  set items(items: any[]) {
    if (!_.isEqual(this._items, items)) {
      this._items = items;
      if (items.length > 0) {
        this.createColumnHeaders();
        this.loadDataTable();
      }
    }
  }
  get items(): any[] {
    return this._items;
  }

  get columnHeaders(): any[] {
    return this._columnHeaders;
  }

  private _items: any[] = [];
  private _columnHeaders: any[] = [];

  constructor() {
  }

  ngOnInit() {
    this._columnHeaders = [];
  }

  createColumnHeaders = function() {
    let tmpColumns = [];

    let width = 90 / this.columns.length + '%';

    tmpColumns.push({
        'sTitle': '<input name="select_all" value="1" id="rows-select-all" type="checkbox" />',
        'bSortable': false,
        'sWidth': '3%'
      });

    for (let i = 0; i < this.columns.length; i++) {
      tmpColumns.push(
        {
          'sTitle': this.columns[i].text,
          'bSortable': this.sortable,
          'sWidth': ((this.columns[i].text === 'Actions') ? '95px' : width + '%')
        }
      );
    }

    if (this.showActions) {
      tmpColumns.push(
        {
          'sTitle': 'Actions',
          'bSortable': false,
          'sWidth': '95px'
        }
      );
    }

    this._columnHeaders = tmpColumns;
  };

  loadDataTable = function() {
    let actions = '';
    let tmpItems = [];
    let curItems = this.items;
    let curOnCheck = this.onCheck;
    let curOnClone = this.onClone;
    let curOnActivate = this.onActivate;
    let curOnDelete = this.onDelete;
    let curOnSelectAll = this.onSelectAll;
    let curOnEdit = this.onEdit;
    let curOnNavigate = this.onNavigate;
    let curOnInfo = this.onInfo;
    let curOnManage = this.onManage;

    for (let i = 0; i < this.items.length; i++) {
      tmpItems.push([]);
      tmpItems[i].id = this.items[i].id;
      tmpItems[i][0] = '';
      if (this.showActions) {
        tmpItems[i].push(new Array(this.items.length + 1));
      } else {
        tmpItems[i].push(new Array(this.items.length));
      }

      for (let j = 0; j < this.columns.length; j++) {
        tmpItems[i][j + 1] = this.columns[j].formatter.format(this.items[i]);
      }
    }

    if (this.showActions) {
      if ( this.dismissButton ) {
        actions = '<div id="delete" class="pull-left actionButtons">' +
          '<i class="fa fa-minus-circle fa-2x red" ' +
          'data-toggle="tooltip" data-placement="top" ' +
          'title="Dismiss"></i>' +
          '</div>';
      } else {
        if (this.showDeleteOnly) {
          actions = actions +
            '<div id="delete" class="pull-left actionButtons">' +
            '<i class="fa fa-trash fa-2x red" ' +
            'data-toggle="tooltip" data-placement="top" ' +
            'title="Delete ' + this.typeName + '"></i>' +
            '</div>';
        } else {
          actions = actions +
            '<div id="edit" class="pull-left actionButtons">' +
            '<i class="fa fa-edit fa-2x blue" ' +
            'data-toggle="tooltip" data-placement="top" ' +
            'title="Edit ' + this.typeName + '"></i>' +
            '</div>' +
            '<div id="delete" class="pull-left actionButtons">' +
            '<i class="fa fa-trash fa-2x red" ' +
            'data-toggle="tooltip" data-placement="top" ' +
            'title="Delete ' + this.typeName + '"></i>' +
            '</div>';
        }
      }
      if (this.showInfo) {
          actions = actions +
            '<div id="info" class="pull-left actionButtons">' +
            '<i class="fa fa-info fa-2x blue" data-toggle="tooltip" data-placement="top" ' +
            'title="' + this.typeName + ' Status"></i>' +
            '</div>';
      }
      if (this.showManage) {
          actions = actions +
            '<div id="manage" class="pull-left actionButtons">' +
              '<i class="fa fa-sitemap fa-2x green" data-toggle="tooltip" data-placement="top" ' +
            'title="' + this.typeName + ' Management"></i>' +
            '</div>';
      }
    }
    
    let dataTable = ($('#datatable-id') as any).DataTable( {
      destroy: true,
      processing: true,
      data: tmpItems,
      rowId: 'id',
      columns: this.columnHeaders,
      scrollCollapse: true,
      info:           false,
      paging:         false,
      columnDefs: [
        {
          targets: 0,
          orderable: false,
          visible: this.showCheckboxes,
          className: 'dt-body-center',
          render: function (data, type, full, meta){
             return '<input type="checkbox" name="id[]" value="'
                + $('<div/>').text(data).html() + '">';
          }
        },
        {
          targets: -1,
          data: undefined,
          defaultContent: actions
        }
      ],
      order: [[ this.sortColumn, this.sortAscending ? 'asc' : 'desc' ]],
      lengthMenu: [[10, 25, 50, -1], [10, 25, 50, 'All']]
    });

    jQuery('<div style="overflow: auto"></div>')
        .append($('#datatable-id')).insertAfter($('#datatable-id_wrapper div').first());

    jQuery('#datatable-id tbody').off( 'click', 'div');

    jQuery('#datatable-id tbody').on( 'click', 'div', function () {
      let data = dataTable.row( $(this).parents('tr') ).id();
      for (let i = 0; i < curItems.length; i++) {
        if (curItems[i].id === data) {
          if (this.id.indexOf('clone') >= 0) {
            curOnClone.emit(curItems[i]);
            break;
          }
          if (this.id.indexOf('activate') >= 0) {
            curOnActivate.emit(curItems[i]);
            break;
          }
          if (this.id.indexOf('edit') >= 0) {
            curOnEdit.emit(curItems[i]);
            break;
          }
          if (this.id.indexOf('delete') >= 0) {
            curOnDelete.emit(curItems[i]);
            break;
          }
          if (this.id.indexOf('check') >= 0) {
            curOnCheck.emit(curItems[i]);
            break;
          }
          if (this.id.indexOf('navigate') >= 0) {
            curOnNavigate.emit(curItems[i]);
            break;
          }
          if (this.id.indexOf('info') >= 0) {
            curOnInfo.emit(curItems[i]);
            break;
          }
          if (this.id.indexOf('manage') >= 0) {
            curOnManage.emit(curItems[i]);
            break;
          }
        }
      }
    });

  //   jQuery('#rows-select-all').on( 'click', function () {
  //     let rows = dataTable.rows({ 'search': 'applied' }).nodes();
  //     $('input[type="checkbox"]', rows).prop('checked', this.checked);
  //   });

  //   jQuery('#datatable-id thead tr th').on( 'click', 'input', function () {
  //     if (!this.allSelected) {
  //       dataTable.rows().select();
  //       curOnSelectAll.emit();
  //       this.allSelected = true;
  //     } else {
  //       dataTable.rows().deselect();
  //       curOnSelectAll.emit();
  //       this.allSelected = false;
  //     }
  //   });

  //  jQuery('#datatable-id tbody').on('change', 'input[type="checkbox"]', function() {
  //       if (!this.checked) {
  //          let element = $('#rows-select-all').get(0);
  //          // If "Select all" control is checked and has 'indeterminate' property
  //          if (element && element.checked && ('indeterminate' in element)) {
  //             // Set visual state of "Select all" control as 'indeterminate'
  //             element.indeterminate = true;
  //          }
  //       }
  //   });
  //   if (this.showCheckboxes) {
  //     jQuery('#datatable-id tbody').on( 'click', 'tr', function () {
  //       let gatewayName = dataTable.row(this).data().id;
  //       if ($('input[type="checkbox"]', this).prop('checked')) {
  //         dataTable.row(this).select();
  //       } else {
  //         dataTable.row(this).deselect();
  //       }
  //       curOnCheck.emit(gatewayName);
  //     });
  //   }
  };
}
