
import { TestBed, async } from '@angular/core/testing';
import { DataTableComponent } from './datatable.component';

import { BrowserDynamicTestingModule, platformBrowserDynamicTesting }
  from '@angular/platform-browser-dynamic/testing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('Component: DataTableComponent', () => {
  let fixture, component, element;

  beforeEach(() => {
    TestBed.resetTestEnvironment();
    TestBed.initTestEnvironment(BrowserDynamicTestingModule,
      platformBrowserDynamicTesting());
    TestBed.configureTestingModule({
      declarations: [
        DataTableComponent
      ],
      imports: [
        BrowserModule,
        FormsModule
      ],
      providers: [],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    });
    TestBed.compileComponents();

    fixture = TestBed.createComponent(DataTableComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
  });

  it('should create column header checkbox', async(() => {
    fixture.detectChanges();
    component.createColumnHeaders();
    expect(component._columnHeaders[0]).toEqual({
      'sTitle': '<input name="select_all" value="1" id="rows-select-all" type="checkbox" />',
      'bSortable': false,
      'sWidth': '3%'
    });
  }));

  // it('should create column headers according to column length', async(() => {
    // component.columns.length = 5;
    // let width = 90 / component.columns.length + '%';
    // fixture.detectChanges();
    // component.createColumnHeaders();
    // expect(component._columnHeaders[component.columns.length]).toEqual({
    //   'sTitle': component.columns[component.columns.length].text,
    //   'bSortable': component.sortable,
    //   'sWidth': ((component.columns[component.columns.length].text === 'Actions')
    //     ? '95px' : width + '%')
    // });
  //
  //   expect(component._columnHeaders.length).toBe(component.columns.length);
  // }));
  //
  // function testMyColumnHeaders(input) {
  //   let width = 90 / component.columns.length + '%';
  //
  //   it('should create column headers with ' + input + ' columns length', async(() => {
  //     expect(component._columnHeaders[input]).toEqual({
  //       'sTitle': this.columns[input].text,
  //       'bSortable': this.sortable,
  //       'sWidth': ((this.columns[input].text === 'Actions') ? '95px' : width + '%')
  //     });
  //   }));
  // }
  //
  // for (let x = 0; x < component.columns.length; x++) {
  //   testMyColumnHeaders(x);
  // }
});
