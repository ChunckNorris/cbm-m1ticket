import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Ui } from '../../services/index';
@Component({
    selector: 'loading-indicator',
    templateUrl: 'loading-indicator.html'
})
export class LoadingIndicator {
    
    isLoading = false;
    private subscription: Subscription;

    constructor(public ui: Ui) { }

    ngOnInit() {
        this.subscription = this.ui.loadingEvent.subscribe(loading => {
            this.isLoading = loading
        });
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
}