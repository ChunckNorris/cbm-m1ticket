import {Component, Input, OnDestroy} from '@angular/core';

@Component({
    selector: 'loading-spinner',
    styleUrls: ['spinner.css'],
    templateUrl: 'spinner.html'
})
export class SpinnerComponent  {  
    private currentTimeout: any;
    private isDelayedRunning: boolean = false;

    @Input()
    public delay: number = 300;

    @Input()
    public set isRunning(value: boolean) {
  
            this.isDelayedRunning = value;
            return;

    }

    private cancelTimeout(): void {
       this.isDelayedRunning = false;
    }

    ngOnDestroy(): any {
        this.cancelTimeout();
    }
}